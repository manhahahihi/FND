# FND
 
1 - Create new evironment
2 - pip install -r requirements.txt
3 - train: python src/train.py
4 - run api: python src/predictor_api.py
5 - run app web: python src/app.py